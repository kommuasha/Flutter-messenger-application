package com.example.chat_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
